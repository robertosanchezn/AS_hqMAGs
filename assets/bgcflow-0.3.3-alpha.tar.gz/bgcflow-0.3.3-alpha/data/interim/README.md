# Intermediate data files for reference

`bgcflow` will generate many output files of various software programs which will be stored in this `interim` data directory. These files could be of importance to regenerate the parts of analysis from a particular step or to understand the details of output from a particular program.

This data directory structure is still in progress and we look for further user casestudies to move files to `processed` directory.

If you think some of the `interim` folder files shall be in the final `processed` directory please inform Omkar Mohite (omkmoh@biosustain.dtu.dk) or Matin Nuhamunada (matinnu@biosustain.dtu.dk). 