# External data files 

This folder is to store any external data files and information that is not directly related to the workflow.