# Processed data files and tables

`bgcflow` will generate final output files for data analysis and exploration purposes in ths `processed` data directory. These files are necessary for the users to recieve as an output of bgcflow

This data directory structure is still in progress and we look for further user casestudies to move files to `interim` directory.

If you think some of the `interim` folder files shall be in the final `processed` directory please inform Omkar Mohite (omkmoh@biosustain.dtu.dk) or Matin Nuhamunada (matinnu@biosustain.dtu.dk). 