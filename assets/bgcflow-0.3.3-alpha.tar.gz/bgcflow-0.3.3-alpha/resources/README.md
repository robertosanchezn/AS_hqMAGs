# Resources files 

This folder is to store databases and other dependencies required to run the rules. If the necessary resources are already available locally, it can be symlinked into the folder.